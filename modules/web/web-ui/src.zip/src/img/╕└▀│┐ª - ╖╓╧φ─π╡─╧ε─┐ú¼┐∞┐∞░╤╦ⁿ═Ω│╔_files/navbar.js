angular.module('MyApp')
    .controller('NavbarCtrl', function ($scope, $location, AccountService) {
//        $scope.isAuthenticated = function () {
//            console.info("auth");
//            $scope.user = AccountService.getCurrentUser();
//            return $auth.isAuthenticated();
//        };
        $scope.isActive = function (viewLocation) {
            return viewLocation === $location.path() || $location.path().indexOf(viewLocation + "/") == 0;
        };
        $scope.$watch(AccountService.isLogin,
            function (isLogin) {
                if (isLogin) {
                    $scope.isAuthenticated = true;
                    $scope.currentUser = AccountService.currentUser();
                } else {
                    $scope.isAuthenticated = false;
                    $scope.currentUser = AccountService.currentUser();
                }
            }
        )
        ;
    });