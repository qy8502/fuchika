angular.module('MyApp')
    .controller('ProjectCtrl', function ($state, $scope, ProjectService, AppMessager) {

        $('#side-affix').affix({ offset: { top: 220, bottom: 200 } });
        ProjectService.getTagListPop()
            .then(function (response) {
                $scope.tagListPop = response.data;
            })
            .catch(function (response) {
                AppMessager.errorResponse(response);
            });

        ProjectService.getProjectListOwn()
            .then(function (response) {
                $scope.projectListOwn = response.data;
            })
            .catch(function (response) {
                AppMessager.errorResponse(response);
            });
        ProjectService.getProjectListJoin()
            .then(function (response) {
                $scope.projectListJoin = response.data;
            })
            .catch(function (response) {
                AppMessager.errorResponse(response);
            });
        ProjectService.getProjectListFollow()
            .then(function (response) {
                $scope.projectListFollow = response.data;
            })
            .catch(function (response) {
                AppMessager.errorResponse(response);
            });
        ProjectService.getProjectListPop()
            .then(function (response) {
                $scope.projectListPop = response.data;
            })
            .catch(function (response) {
                AppMessager.errorResponse(response);
            });


    })
    .controller('ProjectDetailCtrl', function ($stateParams, $scope, ProjectService, AppMessager) {
        console.log($stateParams.projectId);
        ProjectService.getProject($stateParams.projectId)
            .then(function (response) {
                $scope.project = response.data;
            })
            .catch(function (response) {
                AppMessager.errorResponse(response);
            });


    });